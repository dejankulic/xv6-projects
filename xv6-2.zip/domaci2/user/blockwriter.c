#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

#define defsize 50
#define blocksize 512

char block[512] = "opqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwerqwertyuiopqwertyuiopqwertyuiopqwertyuiopqtyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertywertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiotyuioppqwertyuiopqwertyuiopqwertyuiopqweruiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiqwertyuiopqwuiop";

int
main(int argc, char *argv[])
{
	
	int file_desc;
	//0x200 kreira file
	//0x002 otvara za citanje i pisanje
	//w
 	

	int i = 0;
	int ans = 0;
	//ans hvatam koliko karaktera sam upisao u file;

	//velicina bloka je 512; ja upisem jedan blok sad(character counter)

	if(poredjenje("-h",argv[1]) == 0){
		printf("--output-file (-o) FILENAME postavlja ime za novokreiranu datoteku \n--blocks (-b) BLOCKS postavlja broj blokova za ispisivanje na BLOCKS.\n");
		exit();	
	}else if(poredjenje("--help",argv[1]) == 0){
		printf("--output-file (-o) FILENAME postavlja ime za novokreiranu datoteku \n--blocks (-b) BLOCKS postavlja broj blokova za ispisivanje na BLOCKS.\n");
		exit();	
	}else if((poredjenje("--output-file",argv[1]) == 0 || poredjenje("-o",argv[1]) == 0) && (poredjenje("--blocks",argv[3]) == 0  || poredjenje("-b",argv[3]) == 0)){
		file_desc = blockwriter(argv[2],0x200|0x002);
		int size = atoi(argv[4]);
		while(i < size)
		{
			ans = write(file_desc,block,512);
			if(ans != 512){
				printf("greska blockwriter\n");
				exit();
			}		

			printf("create block %d\n",i);
			i++;
		}

	}else if((poredjenje("--output-file",argv[3]) == 0 || poredjenje("-o",argv[3]) == 0) && (poredjenje("--blocks",argv[1]) == 0  || poredjenje("-b",argv[1]) == 0)){
		file_desc = blockwriter(argv[4],0x200|0x002);
		int size = atoi(argv[2]);
		while(i < size)
		{
			ans = write(file_desc,block,512);
			if(ans != 512){
				printf("greska blockwriter\n");
				exit();
			}		

			printf("create block %d\n",i);
			i++;
		}
	}else if(poredjenje("--output-file",argv[1]) == 0){
		
		file_desc = blockwriter(argv[2],0x200|0x002);
		while(i < defsize)
		{
			ans = write(file_desc,block,512);
			if(ans != 512){
				printf("greska blockwriter\n");
				exit();
			}		

			printf("create block %d\n",i);
			i++;
		}
	}else if(poredjenje("-o",argv[1]) == 0){
		
		file_desc = blockwriter(argv[2],0x200|0x002);
		while(i < defsize)
		{
		
		
			ans = write(file_desc,block,512);

			if(ans != 512){
				printf("greska blockwriter\n");
				exit();
			}		
			printf("create block %d\n",i);
			i++;
		}
	}else if(poredjenje("--blocks",argv[1]) == 0){
		file_desc = blockwriter("long.tx",0x200|0x002);
		int size = atoi(argv[2]);
				
		while(i < size)
		{
			
		
			ans = write(file_desc,block,512);

			if(ans != 512){
				printf("greska blockwriter\n");
				exit();
			}		
			printf("create block %d\n",i);
			i++;
		}

	}
	else if(poredjenje("-b",argv[1]) == 0){
		file_desc = blockwriter("long.txt",0x200|0x002);
		int size = atoi(argv[2]);
				
		while(i < size)
		{
			
		
			ans = write(file_desc,block,512);

			if(ans != 512){
				printf("greska blockwriter\n");
				exit();
			}		
			printf("create block %d\n",i);
			i++;
		}
	}
	exit();
}

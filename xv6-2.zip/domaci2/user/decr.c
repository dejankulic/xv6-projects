#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{

	if(poredjenje("--help",argv[1]) == 0){
		printf("--decrypt-all (-a) dekriptuje sve enkriptovane fajlove u trenutnom direktorijumu.\n");	
		exit();
	}else if(poredjenje("-h",argv[1]) == 0)
	{
		printf("--decrypt-all (-a) dekriptuje sve enkriptovane fajlove u trenutnom direktorijumu.\n");	
		exit();
	}else if(poredjenje("--decrypt-all",argv[1]) == 0){
		printf("dekriptovati sve\n");
	}else if(poredjenje("-a",argv[1]) == 0){
		printf("dekriptovati aaa sve\n");
		
	}else if(argc == 1){
		printf("help Meni sad\n");	
		
	}else{
		int file_descriptor = open(argv[1], 0x200 | 0x002);
		int odgovor;
		odgovor = decr(file_descriptor);
		if(odgovor == -1){
			printf("nije setovan kljuc\n");
		}else if(odgovor == -2){
			printf("pokusano je dekriptovati T_DEV\n");
		}else if(odgovor == -3){
			printf("file nije enkriptovan\n");
		}else if(odgovor == 0){
			printf("Uspesno ste dekriptovali %s\n", argv[1]);
		}
	}

	exit();
}

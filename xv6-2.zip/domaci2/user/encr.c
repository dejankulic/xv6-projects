#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{

	if(poredjenje("--help",argv[1]) == 0){
		printf("--encrypt-all (-a) enkriptuje sve ne-enkriptovane fajlove u trenutnom direktorijumu.\n");	
		exit();
	}else if(poredjenje("-h",argv[1]) == 0)
	{
		printf("--encrypt-all (-a) enkriptuje sve ne-enkriptovane fajlove u trenutnom direktorijumu.\n");	
		exit();
	}else if(poredjenje("--encrypt-all",argv[1]) == 0){
		printf("enkriptovati sve\n");
	}else if(poredjenje("-a",argv[1]) == 0){
		printf("enkriptovati sve\n");
		
	}else if(argc == 1){
		printf("help Meni sad\n");	
		
	}else{
		int file_descriptor = open(argv[1], 0x200 | 0x002);
		int odgovor;
		odgovor = encr(file_descriptor);
		if(odgovor == -1){
			printf("nije setovan kljuc\n");
		}else if(odgovor == -2){
			printf("pokusano je enkriptovati T_DEV\n");
		}else if(odgovor == -3){
			printf("datoteka je vec enkriptovana\n");
		}else if(odgovor == 0){
			printf("Uspesno enkriptovano %s\n", argv[1]);
		}
	}
	

	exit();
}

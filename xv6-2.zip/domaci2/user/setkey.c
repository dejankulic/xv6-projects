#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
	

	if(poredjenje("--help",argv[1]) == 0){
		printf("--secret (-s) uzima ključ sa STDIN-a i pritom sakriva ključ uz pomoć sistemskog poziva setecho.\n");	
		exit();
	}else if(poredjenje("-h",argv[1]) == 0)
	{
		printf("--secret (-s) uzima ključ sa STDIN-a i pritom sakriva ključ uz pomoć sistemskog poziva setecho.\n");
		exit();
	}else if(poredjenje("--secret",argv[1]) == 0){
		setecho(5);
		char niz[10];
		read(0, niz, 10);
		setecho(1);		
		setkey(atoi(niz));
		
// 1 za set cho staflja fleg na f a bilo sta drugo na 0 

	}else if(poredjenje("-s",argv[1]) == 0){
		setecho(5);
		char niz[10];
		read(0, niz, 10);
		setecho(1);		
		setkey(atoi(niz));
		
	}else{
		if(argc == 2){
			setkey(atoi(argv[1]));
		}
	}


	exit();
}

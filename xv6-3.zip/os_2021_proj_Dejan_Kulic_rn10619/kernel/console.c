// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"

static void consputc(int);
void promena_pozicije(int);
static ushort terminali[7][2300];
static uint aktivni = 1; //aktivni terminal

//definise boju za pozadinu
static ushort color1 = 0x1000;
static ushort color2 = 0x2000;
static ushort color3 = 0x3000;
static ushort color4 = 0x4000;
static ushort color5 = 0x5000;
static ushort color6 = 0x6000;


static uint brojac[7];
static char niz1[7][200]  = {"1","1","1","1","1","1","1"};
static char niz2[7][200]  = {"2","2","2","2","2","2","2"};
static char niz3[7][200]  = {"3","3","3","3","3","3","3"};
static char niz4[7][200]  = {"4","4","4","4","4","4","4"};
static char niz5[7][200]  = {"5","5","5","5","5","5","5"};
static char niz6[7][200]  = {"6","6","6","6","6","6","6"};
static char niz7[7][200]  = {"7","7","7","7","7","7","7"};
static char pomocni[7][200];


static int panicked = 0;

static struct {
	struct spinlock lock;
	int locking;
} cons;


static void
printint(int xx, int base, int sign)
{
	static char digits[] = "0123456789abcdef";
	char buf[16];
	int i;
	uint x;

	if(sign && (sign = xx < 0))
		x = -xx;
	else
		x = xx;

	i = 0;
	do{
		buf[i++] = digits[x % base];
	}while((x /= base) != 0);

	if(sign)
		buf[i++] = '-';

	while(--i >= 0)
		consputc(buf[i]);
}

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
	int i, c, locking;
	uint *argp;
	char *s;

	locking = cons.locking;
	if(locking)
		acquire(&cons.lock);

	if (fmt == 0)
		panic("null fmt");

	argp = (uint*)(void*)(&fmt + 1);
	for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
		if(c != '%'){
			consputc(c);
			continue;
		}
		c = fmt[++i] & 0xff;
		if(c == 0)
			break;
		switch(c){
		case 'd':
			printint(*argp++, 10, 1);
			break;
		case 'x':
		case 'p':
			printint(*argp++, 16, 0);
			break;
		case 's':
			if((s = (char*)*argp++) == 0)
				s = "(null)";
			for(; *s; s++)
				consputc(*s);
			break;
		case '%':
			consputc('%');
			break;
		default:
			// Print unknown % sequence to draw attention.
			consputc('%');
			consputc(c);
			break;
		}
	}

	if(locking)
		release(&cons.lock);
}

// Function to implement `strcpy()` function
char* kopiranje(char* destination, const char* source)
{
 
    // take a pointer pointing to the beginning of the destination string
    char *ptr = destination;
 
    // copy the C-string pointed by source into the array
    // pointed by destination
    while (*source != '\0')
    {
        *destination = *source;
        destination++;
        source++;
    }
 
    // include the terminating null character
    *destination = '\0';
 
    // the destination is returned by standard `strcpy()`
    return ptr;
}

void
panic(char *s)
{
	int i;
	uint pcs[10];

	cli();
	cons.locking = 0;
	// use lapiccpunum so that we can call panic from mycpu()
	cprintf("lapicid %d: panic: ", lapicid());
	cprintf(s);
	cprintf("\n");
	getcallerpcs(&s, pcs);
	for(i=0; i<10; i++)
		cprintf(" %p", pcs[i]);
	panicked = 1; // freeze other CPU
	for(;;)
		;
}

#define BACKSPACE 0x100
#define CRTPORT 0x3d4
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory

static void
cgaputc(int c)
{
	int pos;

	// Cursor position: col + 80*row.
	outb(CRTPORT, 14);
	pos = inb(CRTPORT+1) << 8;
	outb(CRTPORT, 15);
	pos |= inb(CRTPORT+1);

	if(c == '\n')
		pos += 80 - pos%80;
	else if(c == BACKSPACE){
		if(pos > 0) --pos;
	} else{
        if(aktivni == 1)
            crt[pos++] = (c&0xff) | color1;  // black on white
        else if(aktivni == 2)
            crt[pos++] = (c&0xff) | color2;  // black on white
        else if(aktivni == 3)
            crt[pos++] = (c&0xff) | color3;  // black on white
        else if(aktivni == 4)
            crt[pos++] = (c&0xff) | color4;  // black on white
        else if(aktivni == 5)
            crt[pos++] = (c&0xff) | color5;  // black on white
        else if(aktivni == 6)
            crt[pos++] = (c&0xff) | color6;  // black on white
    
        
    }
	if(pos < 0 || pos > 25*80)
		panic("pos under/overflow");

	if((pos/80) >= 24){  // Scroll up.
		memmove(crt, crt+80, sizeof(crt[0])*23*80);
		pos -= 80;
		memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
        int i = pos;
        while(i < 24*80){
            if(aktivni == 1)
                crt[i] |= color1;  // black on white
            else if(aktivni == 2)
                crt[i] |= color2;  // black on white
            else if(aktivni == 3)
                crt[i] |= color3;  // black on white
            else if(aktivni == 4)
                crt[i] |= color4;  // black on white
            else if(aktivni == 5)
                crt[i] |= color5;  // black on white
            else if(aktivni == 6)
                crt[i] |= color6;  // black on white
        
            i++;
        }

	}
	promena_pozicije(pos);

	outb(CRTPORT, 14);
	outb(CRTPORT+1, pos>>8);
	outb(CRTPORT, 15);
	outb(CRTPORT+1, pos);
    if(aktivni == 1)
        crt[pos] = ' ' | color1;
    else if(aktivni == 2)
        crt[pos] = ' ' | color2;
    else if(aktivni == 3)
        crt[pos] = ' ' | color3;
    else if(aktivni == 4)
        crt[pos] = ' ' | color4;
    else if(aktivni == 5)
        crt[pos] = ' ' | color5;
    else if(aktivni == 6)
        crt[pos] = ' ' | color6;
}

void
consputc(int c)
{
	if(panicked){
		cli();
		for(;;)
			;
	}

	if(c == BACKSPACE){
		uartputc('\b'); uartputc(' '); uartputc('\b');
	} else
		uartputc(c);
	cgaputc(c);
}

#define INPUT_BUF 128
struct {
	char buf[7][INPUT_BUF];
	uint r[7];  // Read index
	uint w[7];  // Write index
	uint e[7];  // Edit index
	
	int pozicije[7];
} input;

void promena_pozicije(int pozicija)
{
    if(pozicija > 0)
        input.pozicije[aktivni] = pozicija;
}

#define A(x)  ((x)-'0')  // Control-x
#define C(x)  ((x)-'@')  // Control-x

void logic(int novi_terminal)
{
    for(int i=0;i<input.pozicije[aktivni];i++)
        terminali[aktivni][i] = crt[i];
    
    for(int i=0;i < 2000;i++)
        crt[i] = ' ';
    
    aktivni = novi_terminal;
    
    for(int i=0;i<=input.pozicije[novi_terminal];i++){
        if(i == input.pozicije[novi_terminal]){
            outb(CRTPORT, 14);
            outb(CRTPORT+1, i>>8);
            outb(CRTPORT, 15);
            outb(CRTPORT+1, i);
            if(aktivni == 1){
                crt[i] = ' ' | color1;
                crt[1999] = (aktivni + 48) | color1;
            }else if(aktivni == 2){
                crt[i] = ' ' | color2;
                crt[1999] = (aktivni + 48) | color2;
            }else if(aktivni == 3){
                crt[i] = ' ' | color3;
                crt[1999] = (aktivni + 48) | color3;
            }else if(aktivni == 4){
                crt[i] = ' ' | color4;
                crt[1999] = (aktivni + 48) | color4;
            }else if(aktivni == 5){
                crt[i] = ' ' | color5;
                crt[1999] = (aktivni + 48) | color5;
            }else if(aktivni == 6){
                crt[i] = ' ' | color6;
                crt[1999] = (aktivni + 48) | color6;
            }
        }else
            crt[i] = terminali[aktivni][i];
    }
    
      int a=0;
        while(a < 2000){
            crt[a] &= 0xff;
            if(aktivni == 1)
                crt[a] |= color1;
            else if(aktivni == 2)
                crt[a] |= color2;
            else if(aktivni == 3)
                crt[a] |= color3;
            else if(aktivni == 4)
                crt[a] |= color4;
            else if(aktivni == 5)
                crt[a] |= color5;
            else if(aktivni == 6)
                crt[a] |= color6;
            
                
            a++;
        }
}


void
consoleintr(int (*getc)(void))
{
	int c, doprocdump = 0;
    int i = 0, granica = 0, end;
    char reversecpyniz[200];
    char cpyniz[200] = {'\0'};
    reversecpyniz[0]= '\0';
    
	acquire(&cons.lock);
	while((c = getc()) >= 0){
        switch(c){
		case A('1'):
            if(1 != aktivni)
                logic(1);
            break;
		case A('2'):
            if(2 != aktivni)
                logic(2);
            break;
		case A('3'):
            if(3 != aktivni)
                logic(3);
            break;
		case A('4'):
            if(4 != aktivni)
                logic(4);
            break;        
		case A('5'):
            if(5 != aktivni)
                logic(5);
            break;     
		case A('6'):
            if(6 != aktivni)
                logic(6);
            break;            

		case C('P'):  // Process listing.
			// procdump() locks cons.lock indirectly; invoke later
			doprocdump = 1;
			break;
        case C('U'): case 0xE2: case 0xE3:  // Kill line.
            if(c == 0xE2){
                if(brojac[aktivni] == 0){
                    granica = input.e[aktivni] - input.w[aktivni];
                    while(i < granica){
                        pomocni[aktivni][i] = input.buf[aktivni][(input.e[aktivni]-i-1) % INPUT_BUF];
                        i++;
                    }
                    pomocni[aktivni][i] = '\0';
                 
                    end = strlen(pomocni[aktivni]) - 1;
                    for(i = 0; i < strlen(pomocni[aktivni]);i++){
                        reversecpyniz[i] = pomocni[aktivni][end];
                        end--;
                    }
                    reversecpyniz[i] = '\0';
                    kopiranje(pomocni[aktivni],reversecpyniz);
                }
                    
            }
            
            while(input.e[aktivni] != input.w[aktivni] && input.buf[aktivni][(input.e[aktivni]-1) % INPUT_BUF] != '\n'){
				input.e[aktivni]--;
				consputc(BACKSPACE);
			}
		
            
            if(c == 0xE2){
                if(brojac[aktivni] == 0)
                    kopiranje(cpyniz,niz1[aktivni]);
                else if(brojac[aktivni] == 1)
                    kopiranje(cpyniz,niz2[aktivni]);
                else if(brojac[aktivni] == 2)
                    kopiranje(cpyniz,niz3[aktivni]);
                else if(brojac[aktivni] == 3)
                    kopiranje(cpyniz,niz4[aktivni]);
                else if(brojac[aktivni] == 4)
                    kopiranje(cpyniz,niz5[aktivni]);
                else if(brojac[aktivni] == 5)
                    kopiranje(cpyniz,niz6[aktivni]);
                else if(brojac[aktivni] == 6)
                    kopiranje(cpyniz,niz7[aktivni]);
                else if(brojac[aktivni] == 7)
                    kopiranje(cpyniz,niz7[aktivni]);
            }
            
            if(c == 0xE3){
                if(brojac[aktivni] == 0)
                    kopiranje(cpyniz,pomocni[aktivni]);
                else if(brojac[aktivni] == 1)
                    kopiranje(cpyniz,pomocni[aktivni]);
                else if(brojac[aktivni] == 2)
                    kopiranje(cpyniz,niz1[aktivni]);
                else if(brojac[aktivni] == 3)
                    kopiranje(cpyniz,niz2[aktivni]);
                else if(brojac[aktivni] == 4)
                    kopiranje(cpyniz,niz3[aktivni]);
                else if(brojac[aktivni] == 5)
                    kopiranje(cpyniz,niz4[aktivni]);
                else if(brojac[aktivni] == 6)
                    kopiranje(cpyniz,niz5[aktivni]);
                else if(brojac[aktivni] == 7)
                    kopiranje(cpyniz,niz6[aktivni]);
            }
            
            	
			if(c == 0xE2 && brojac[aktivni] != 7 && strlen(cpyniz) != 0)
                brojac[aktivni]++;
            if(c == 0xE3 && brojac[aktivni] != 0)
                brojac[aktivni]--;
            
			if(c == 0xE2 || c == 0xE3){
                i = 0;
                while(cpyniz[i] != '\0'){
                    input.buf[aktivni][input.e[aktivni]++ % INPUT_BUF] = cpyniz[i];
                    consputc(cpyniz[i]);
                    i++; 
                }
            }
			break;
		case C('H'): case '\x7f':  // Backspace
			if(input.e[aktivni] != input.w[aktivni]){
				input.e[aktivni]--;
				consputc(BACKSPACE);
			}
			break;
		default:
			if(c != 0 && input.e[aktivni]-input.r[aktivni] < INPUT_BUF){
				if(c == '\r' || c == '\n'){
                    granica = input.e[aktivni] - input.w[aktivni];
                    while(i < granica){
                        pomocni[aktivni][i] = input.buf[aktivni][(input.e[aktivni]-i-1) % INPUT_BUF];
                        i++;
                    }
                    pomocni[aktivni][i] = '\0';
                 
                    end = strlen(pomocni[aktivni]) - 1;
                    for(i = 0; i < strlen(pomocni[aktivni]);i++){
                        reversecpyniz[i] = pomocni[aktivni][end];
                        end--;
                    }
                    reversecpyniz[i] = '\0';
                    kopiranje(pomocni[aktivni],reversecpyniz);
                }
                c = (c == '\r') ? '\n' : c;
				input.buf[aktivni][input.e[aktivni]++ % INPUT_BUF] = c;
				consputc(c);
				if(c == '\n' || c == C('D') || input.e[aktivni] == input.r[aktivni]+INPUT_BUF){
                  
                   
                    kopiranje(niz7[aktivni],niz6[aktivni]);
                    kopiranje(niz6[aktivni],niz5[aktivni]);
                    kopiranje(niz5[aktivni],niz4[aktivni]);
                    kopiranje(niz4[aktivni],niz3[aktivni]);
                    kopiranje(niz3[aktivni],niz2[aktivni]);
                    kopiranje(niz2[aktivni],niz1[aktivni]);
                    kopiranje(niz1[aktivni],pomocni[aktivni]);
                    brojac[aktivni] = 0;
					input.w[aktivni] = input.e[aktivni];
					wakeup(&input.r[aktivni]);
				}
			}
			break;
		}
	}
	release(&cons.lock);
	if(doprocdump) {
		procdump();  // now call procdump() wo. cons.lock held
	}
}

int
consoleread(struct inode *ip, char *dst, int n)
{
	uint target;
	int c;

	iunlock(ip);
	target = n;
	acquire(&cons.lock);
	while(n > 0){
		while(input.r[aktivni] == input.w[aktivni]){
			if(myproc()->killed){
				release(&cons.lock);
				ilock(ip);
				return -1;
			}
			sleep(&input.r[ip->minor], &cons.lock);
		}
		c = input.buf[aktivni][input.r[aktivni]++ % INPUT_BUF];
		if(c == C('D')){  // EOF
			if(n < target){
				// Save ^D for next time, to make sure
				// caller gets a 0-byte result.
				input.r[aktivni]--;
			}
			break;
		}
		*dst++ = c;
		--n;
		if(c == '\n')
			break;
	}
	release(&cons.lock);
	ilock(ip);

	return target - n;
}

int inicijalizacija = 0;

int
consolewrite(struct inode *ip, char *buf, int n)
{
	int i;
    if(inicijalizacija == 0){
        crt[1999] = '1' | 0x1000;
        inicijalizacija++;
        int a=0;
        while(a < 2000){
            crt[a] &= 0xff;
            crt[a] |= color1;
            a++;
        }
    }
    if (ip->minor != aktivni) {
        if (buf[0] == '\n'){
            input.pozicije[ip->minor] = input.pozicije[ip->minor] + 80 - (input.pozicije[ip->minor] % 80);
        }else{
            input.pozicije[ip->minor]++;
            if(aktivni == 1)
                terminali[ip->minor][input.pozicije[ip->minor]-1] = buf[0] | color1;
            else if(aktivni == 2)
                terminali[ip->minor][input.pozicije[ip->minor]-1] = buf[0] | color2;
            else if(aktivni == 3)
                terminali[ip->minor][input.pozicije[ip->minor]-1] = buf[0] | color3;
            else if(aktivni == 4)
                terminali[ip->minor][input.pozicije[ip->minor]-1] = buf[0] | color4;
            else if(aktivni == 5)
                terminali[ip->minor][input.pozicije[ip->minor]-1] = buf[0] | color5;
            else if(aktivni == 6)
                terminali[ip->minor][input.pozicije[ip->minor]-1] = buf[0] | color6;
            
                
        }
        return n;
    }else{
        iunlock(ip);
        acquire(&cons.lock);
        for(i = 0; i < n; i++)
            consputc(buf[i]);
        release(&cons.lock);
        ilock(ip);

        return n;
    }
}

void
consoleinit(void)
{
	initlock(&cons.lock, "console");
    
    
	devsw[CONSOLE].write = consolewrite;
	devsw[CONSOLE].read = consoleread;
	cons.locking = 1;

	ioapicenable(IRQ_KBD, 0);

}

//newColor -> nova boja koja ce da bude 
//flag -> 0 menjam fg, 1 menjam bg, 2 menjam oba, 3 fg svetlo, 4 bg svetlo, 5 oba menja ali na default
void
ccolor(ushort newColor, int flag){
    if(flag == 2 || flag == 5){
        if(aktivni == 1)
            color1 &= 0x0000;
        else if(aktivni == 2)
            color2 &= 0x0000;
        else if(aktivni == 3)
            color3 &= 0x0000;
        else if(aktivni == 4)
            color4 &= 0x0000;
        else if(aktivni == 5)
            color5 &= 0x0000;
        else if(aktivni == 6)
            color6 &= 0x0000;
    }
    else if(flag == 0 || flag == 3){
        if(aktivni == 1)
            color1 &= 0xf000;
        else if(aktivni == 2)
            color2 &= 0xf000;
        else if(aktivni == 3)
            color3 &= 0xf000;
        else if(aktivni == 4)
            color4 &= 0xf000;
        else if(aktivni == 5)
            color5 &= 0xf000;
        else if(aktivni == 6)
            color6 &= 0xf000;
    }
    else{
        if(aktivni == 1)
            color1 &= 0x0f00;
        else if(aktivni == 2)
            color2 &= 0x0f00;
        else if(aktivni == 3)
            color3 &= 0x0f00;
        else if(aktivni == 4)
            color4 &= 0x0f00;
        else if(aktivni == 5)
            color5 &= 0x0f00;
        else if(aktivni == 6)
            color6 &= 0x0f00;
    }
    
    if(flag == 3){
        if(aktivni == 1)
            color1 |= 0x0800;
        else if(aktivni == 2)
            color2 |= 0x0800;
        else if(aktivni == 3)
            color3 |= 0x0800;
        else if(aktivni == 4)
            color4 |= 0x0800;
        else if(aktivni == 5)
            color5 |= 0x0800;
        else if(aktivni == 6)
            color6 |= 0x0800;
    }
    if(flag == 4){
        if(aktivni == 1)
            color1 |= 0x8000;
        else if(aktivni == 2)
            color2 |= 0x8000;
        else if(aktivni == 3)
            color3 |= 0x8000;
        else if(aktivni == 4)
            color4 |= 0x8000;
        else if(aktivni == 5)
            color5 |= 0x8000;
        else if(aktivni == 6)
            color6 |= 0x8000;
    }
    
    if(aktivni == 1)
        color1 |= newColor;
    else if(aktivni == 2)
        color2 |= newColor;
    else if(aktivni == 3)
        color3 |= newColor;
    else if(aktivni == 4)
        color4 |= newColor;
    else if(aktivni == 5)
        color5 |= newColor;
    else if(aktivni == 6)
        color6 |= newColor;    
  
    if(flag == 5){
        if(aktivni == 1)
            color1 |= 0x1000;
        else if(aktivni == 2)
            color2 |= 0x2000;
        else if(aktivni == 3)
            color3 |= 0x3000;
        else if(aktivni == 4)
            color4 |= 0x4000;
        else if(aktivni == 5)
            color5 |= 0x5000;
        else if(aktivni == 6)
            color6 |= 0x6000;
        
    }
    
    int i = 0;
    while(i < (25*80)){
        if(aktivni == 1)
            crt[i] = (crt[i]&0xff) | color1;
        else if(aktivni == 2)
            crt[i] = (crt[i]&0xff) | color2;
        else if(aktivni == 3)
            crt[i] = (crt[i]&0xff) | color3;
        else if(aktivni == 4)
            crt[i] = (crt[i]&0xff) | color4;
        else if(aktivni == 5)
            crt[i] = (crt[i]&0xff) | color5;
        else if(aktivni == 6)
            crt[i] = (crt[i]&0xff) | color6;
        i++;
    }
}

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

static char *help_message = "Usage: color [OPTIONS]\nCommand line options:\n        -h, --help: Pomocni meni.\n        reset: Vraca defaul boje (belo slovo na crnoj pozadini).\n        -fg, --foreground: Podesava boju slova.\n        -bg, --background: Podesava boju pozadine.\n        [bez parametara]: jedan hex broj koji opisuje obe boje.\n";

void call_bgfg(char*, int);

int
main(int argc, char *argv[])
{
    if(strcmp(argv[1],"-h") == 0 || strcmp(argv[1],"--help") == 0){
        printf(help_message);
    }else if(strcmp(argv[1],"reset") == 0){
        color(0x0000, 5);
    }else if(strcmp(argv[1],"-fg") == 0 || strcmp(argv[1],"--foreground") == 0){
        if(argc != 3){
            printf("Syntaxx err\n");
            exit();
        }
        char *s = argv[2];
        for(int i= 0; s[i] != '\0' ;i++)
            if(s[i] >= '0' && s[i] <= '9'){
                printf("Syntaxx err\n");
                exit();
            }
        call_bgfg(argv[2], 0);
    }else if(strcmp(argv[1],"-bg") == 0 || strcmp(argv[1],"--background") == 0){
        if(argc != 3){
            printf("Syntaxx err\n");
            exit();
        }
        
        char *s = argv[2];
        for(int i= 0; s[i] != '\0' ;i++)
            if(s[i] >= '0' && s[i] <= '9'){
                printf("Syntaxx err\n");
                exit();
            }
        call_bgfg(argv[2], 1);
    }else if(argc == 2){
        char* s = argv[1];
        
        if(s[0] != '0' || s[1] != 'x'){
            printf("Syntaxx err\n");
            exit();
        }
        
        if(strlen(s) != 4){
            printf("Syntaxx err\n");
            exit();
        }
        
        if((s[2] >= '0' && s[2] <= '7') && (s[3] >= '0' && s[3] <= '7')){
            char pom[5];
            pom[0] = '0';
            pom[1] = 'x';
            pom[2] = s[2];
            pom[3] = '0';
            call_bgfg(pom, 1);
            pom[2] = '0';
            pom[3] = s[3];
            call_bgfg(pom, 0);
        }else{
            printf("Syntaxx err\n");
            exit();
        }
    }else{
        printf("Syntaxx err\n");
        exit();
    }
    
    
    
    exit();
}

//flag je 0 to je fg, flag je 1 to je bg
void call_bgfg(char* c, int flag){
    int l = 0;
    if(c[0] == 'L'){
        l = 1;
        int i = 0;
        while(c[i] != '\0'){
            c[i] = c[i+1];
            i++;
        }
    }
    
    if(strcmp(c,"black") == 0 || strcmp(c,"0x00") == 0){
        if(flag == 0)
            l == 1 ? color(0x0000, 3):color(0x0000, 0);
        else
            l == 1 ? color(0x0000, 4):color(0x0000, 1);
    }else if(strcmp(c,"blue") == 0 || strcmp(c,"0x01") == 0 || strcmp(c,"0x10") == 0){
   
        if(flag == 0)
            l == 0 ? color(0x0100, 0):color(0x0100, 3);
        else
            l == 0 ? color(0x1000, 1):color(0x1000, 4);
    }else if(strcmp(c,"green") == 0 || strcmp(c,"0x02") == 0 || strcmp(c,"0x20") == 0){
         
        if(flag == 0)
            l == 0 ? color(0x0200, 0):color(0x0200, 3);
        else
            l == 0 ? color(0x2000, 1):color(0x2000, 4);
    }else if(strcmp(c,"aqua") == 0 || strcmp(c,"0x03") == 0 || strcmp(c,"0x30") == 0){
   
        if(flag == 0)
            l == 0 ? color(0x0300, 0):color(0x0300, 3);
        else
            l == 0 ? color(0x3000, 1):color(0x3000, 4);
    }else if(strcmp(c,"red") == 0 || strcmp(c,"0x04") == 0 || strcmp(c,"0x40") == 0){
   
        if(flag == 0)
            l == 0 ? color(0x0400, 0):color(0x0400, 3);
        else
            l == 0 ? color(0x4000, 1):color(0x4000, 4);
    }else if(strcmp(c,"purple") == 0 || strcmp(c,"0x05") == 0 || strcmp(c,"0x50") == 0){
   
        if(flag == 0)
            l == 0 ? color(0x0500, 0):color(0x0500, 3);
        else
            l == 0 ? color(0x5000, 1):color(0x5000, 4);
    }else if(strcmp(c,"yellow") == 0 || strcmp(c,"0x06") == 0 || strcmp(c,"0x60") == 0){
        if(flag == 0)
            l == 0 ? color(0x0600, 0):color(0x0600, 3);
        else
            l == 0 ? color(0x6000, 1):color(0x6000, 4);
    }else if(strcmp(c,"white") == 0 || strcmp(c,"0x07") == 0 || strcmp(c,"0x70") == 0){
   
        if(flag == 0)
            l == 0 ? color(0x0700, 0):color(0x0700, 3);
        else
            l == 0 ? color(0x7000, 1):color(0x7000, 4);
    }else{
        printf("Syntaxx err\n");
        exit();
    }
        
}

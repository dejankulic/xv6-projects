// init: The initial user-level program

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fcntl.h"

char *argv[] = { "sh", 0 };

char tty1[100] = "/dev/tty1";
char tty2[100] = "/dev/tty2";
char tty3[100] = "/dev/tty3";
char tty4[100] = "/dev/tty4";
char tty5[100] = "/dev/tty5";
char tty6[100] = "/dev/tty6";

void napraviTerminale(int);

int
main(void)
{
	int i, wpid;

	if(getpid() != 1){
		fprintf(2, "init: already running\n");
		exit();
	}

	if(open("/dev/console", O_RDWR) < 0){
		mknod("/dev/console", 1, 1);
		open("/dev/console", O_RDWR);
	}
	dup(0);  // stdout
	dup(0);  // stderr

	for (i = 1; i <= 6; i++)
		napraviTerminale(i);

	while((wpid=wait()) >= 0)
		;
}

void
napraviTerminale(int n)
{
    int pid;
    
    pid = fork();
    if(pid == 0){
        close(0);
        close(1);
        close(2);
        if(n == 1)
            if(open(tty1, O_RDWR) < 0){
                mknod(tty1, 1, n);
                open(tty1, O_RDWR);
            }
        if(n == 2)
            if(open(tty2, O_RDWR) < 0){
                mknod(tty2, 1, n);
                open(tty2, O_RDWR);
            }
        if(n == 3)
            if(open(tty3, O_RDWR) < 0){
                mknod(tty3, 1, n);
                open(tty3, O_RDWR);
            }
        if(n == 4)
            if(open(tty4, O_RDWR) < 0){
                mknod(tty4, 1, n);
                open(tty4, O_RDWR);
            }
        if(n == 5)
            if(open(tty5, O_RDWR) < 0){
                mknod(tty5, 1, n);
                open(tty5, O_RDWR);
            }
        if(n == 6)
            if(open(tty6, O_RDWR) < 0){
                mknod(tty6, 1, n);
                open(tty6, O_RDWR);
            }
        
        dup(0);
        dup(0);
        exec("/bin/sh", argv);
        printf("init: exec sh failed\n");
        exit();
    }
    if(pid < 0){
        printf("init: fork failed\n");
        exit();
    }
 
}
